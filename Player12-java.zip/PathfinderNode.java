class PathfinderNode{

    int dir;
    double dist;

    PathfinderNode(int dir, int dist){
        this.dir = dir;
        this.dist = dist;
    }
}