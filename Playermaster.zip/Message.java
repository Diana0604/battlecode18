/**
 * Created by David on 25/01/2018.
 */
public class Message {
    int subject, body, round;
    AuxMapLocation mapLoc;
}
