# Battlecode Engine Python 
To develop: 
```
cargo build
python3 -m pip install ./requirements.txt --user
./run_tests.sh
```