print('atest')

import battlecode as bc

print('btest')
for controller in bc.game_turns():
    print('test')
    print(controller.round)

print('afinitio')
